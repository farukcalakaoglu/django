from rest_framework.views import APIView
from .models import kategori
from .serializers import (
    Kategoriserializer,
    KategoriDetailsSerializer,
    KategoriListSerializer
)
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAdminUser
from django.shortcuts import render

def liste(request):
    return render(request,"kategori/index.html")
# kategori liste
class CatalogCategoryList(APIView):
    def get(self, request):
        kategor = kategori.objects.all()
        serializer = KategoriListSerializer(kategor, many=True)

        return Response(serializer.data)


# admin liste
class AdminCategoryList(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        categori = kategori.objects.all()
        serializer = KategoriListSerializer(categori, many=True)

        return Response(serializer.data)


# catalog kategori detay
class CatalogCategoryDetails(APIView):
    def get(self, request, pk):
        try:
            category = kategori.objects.get(pk=pk)

        except kategori.DoesNotExist:
            return Response(
                {"Error": "Aradığınız kategori yok"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = KategoriDetailsSerializer(category)

        return Response(serializer.data)


# admin kategori detay
class AdminCategoryDetails(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request, pk):
        try:
            category = kategori.objects.get(pk=pk)

        except kategori.DoesNotExist:
            return Response(
                {"Error": "Aradığınız kategori yok"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = KategoriDetailsSerializer(category)

        return Response(serializer.data)


# kategori oluştur
class AdminCategoryCreate(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request):
        serializer = Kategoriserializer(data=request.data)

        if serializer.is_valid():
            serializer.save()

            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED
            )

        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST
        )


# kategori düzenle
class AdminCategoryEdit(APIView):
    permission_classes = [IsAdminUser]

    def put(self, request, pk):
        try:
            category = kategori.objects.get(pk=pk)

        except kategori.DoesNotExist:
            return Response(
                {"Error": "Kategori yok"},
                status=status.HTTP_404_NOT_FOUND
            )

        serializer = Kategoriserializer(
            category,
            data=request.data
        )

        if serializer.is_valid():
            serializer.save()

            return Response(serializer.data)

        return Response(
            serializer.errors,
            status=status.HTTP_400_BAD_REQUEST
        )


# kategori sil
class AdminCategoryDelete(APIView):
    permission_classes = [IsAdminUser]

    def delete(self, request, pk):
        try:
            category = kategori.objects.get(pk=pk)

        except kategori.DoesNotExist:
            return Response(
                {"Error": "Kategori yok"},
                status=status.HTTP_404_NOT_FOUND
            )

        category.delete()

        return Response(
            {"message": "Kategori silindi"},
            status=status.HTTP_204_NO_CONTENT
        )