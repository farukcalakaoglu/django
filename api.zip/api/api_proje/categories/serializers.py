from rest_framework import serializers
from .models import kategori
from rest_framework.validators import UniqueValidator


# kategori liste
class KategoriListSerializer(serializers.ModelSerializer):
    class Meta:
        model = kategori
        fields = ["id", "name"]


# kategori detay
class KategoriDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = kategori
        fields = ["id", "name", "description"]


# kategori serializer
class Kategoriserializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)

    name = serializers.CharField(
        max_length=100,
        validators=[
            UniqueValidator(queryset=kategori.objects.all())
        ]
    )

    description = serializers.CharField(
        required=False,
        allow_blank=True,
        allow_null=False
    )

    def validate(self, data):
        name = data.get("name")
        description = data.get("description")

        if description and name == description:
            raise serializers.ValidationError(
                "Name and Description should be different."
            )

        return data

    def validate_name(self, value):
        if len(value) < 2:
            raise serializers.ValidationError(
                "You must enter at least 2 characters"
            )

        return value

    def create(self, validated_data):
        return kategori.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.name = validated_data.get("name", instance.name)
        instance.description = validated_data.get(
            "description",
            instance.description
        )
        instance.save()

        return instance