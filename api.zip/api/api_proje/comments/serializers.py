from rest_framework import serializers
from .models import Comments
from users.serializers import UserSerializer



class CommentSerializers(serializers.ModelSerializer):
    user=serializers.SerializerMethodField()

    class Meta:
        model= Comments
        fields=["id","rating","description","activate","created","update","product","user"]
        exra_kwargs={
            "product":{"read_only":True}

        }

    def get_user(self, obj):
     return obj.user.username if obj.user else None

