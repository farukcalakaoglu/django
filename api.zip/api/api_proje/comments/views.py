from rest_framework import generics
from .models import Comments as Comment
from .serializers import CommentSerializers
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.exceptions import ValidationError, PermissionDenied


class AdminCommentList(generics.ListAPIView):
    serializer_class = CommentSerializers
    permission_classes = [IsAdminUser]

    def get_queryset(self):
        pk = self.kwargs.get("pk")
        queryset = Comment.objects.all()

        if pk is not None:
            queryset = queryset.filter(product_id=pk)

        return queryset.order_by("-update")


class CommentList(generics.ListAPIView):
    serializer_class = CommentSerializers

    def get_queryset(self):
        pk = self.kwargs["pk"]
        return Comment.objects.filter(product_id=pk)


class CommentCreate(generics.CreateAPIView):
    serializer_class = CommentSerializers
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        product_id = self.kwargs.get("pk")
        user = self.request.user

        if Comment.objects.filter(
            product_id=product_id,
            user=user
        ).exists():
            raise ValidationError({
                "message": "You have already commented on this product."
            })

        serializer.save(
            product_id=product_id,
            user=user
        )


class CommentEdit(generics.UpdateAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializers
    permission_classes = [IsAuthenticated]

    def get_object(self):
        obj = super().get_object()

        if obj.user != self.request.user:
            raise PermissionDenied(
                "You dont have permission to edit this comment."
            )

        return obj


class AdminCommentEdit(generics.UpdateAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializers
    permission_classes = [IsAdminUser]


class AdminCommentDelete(generics.DestroyAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializers
    permission_classes = [IsAdminUser]


class CommentDelete(generics.DestroyAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializers
    permission_classes = [IsAuthenticated]

    def get_object(self):
        obj = super().get_object()

        if obj.user != self.request.user:
            raise PermissionDenied(
                "You dont have permission to delete this comment."
            )

        return obj
