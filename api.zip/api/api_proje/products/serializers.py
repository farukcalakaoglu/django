from .models import Product
from rest_framework import serializers
from categories.models import kategori
from rest_framework.validators import UniqueValidator
from comments.serializers import CommentSerializers
from categories.serializers import Kategoriserializer,KategoriListSerializer

class ProductListSerializers(serializers.ModelSerializer):
     category=kategori.objects.all()
     class Meta:
          model: Product
          Fields=["id","name","price","stock","slug","category"]

#--------------------------------------------------------------
class ProductDetailsSerializers(serializers.ModelSerializer):
 comments= CommentSerializers(many=True,read_only=True)
 category=Kategoriserializer()
 class Meta:
     model=Product
     fields=["id","name","price","stock","slug","category","comments"]

#--------------------------------------------------------------
class ProductSerializer(serializers.ModelSerializer):
    name = serializers.CharField(max_length=200, validators = [UniqueValidator(queryset=Product.objects.all())])
    category = serializers.PrimaryKeyRelatedField(
        queryset = kategori.objects.all(),
        error_messages = {
            'does_not_exist': "The selected category is not available.",
            'incorrect_type': "The category id is invalid.",
        }
    )

    class Meta:
        model = Product
        fields = ['id','name','description','price','stock','slug','category']

    def validate_name(self,value):
        if len(value.strip()) < 3:
            raise serializers.ValidationError("Product name must be at least 3 characters.")
        return value
        
    def validate_price(self, value):
        if value < 0:
            raise serializers.ValidationError("Price must be greater that 0.")
        
        if value > 100000:
            raise serializers.ValidationError("Price seems unusually high.")
        
        return value
        
    def validate_stock(self, value):
        if value < 0:
            raise serializers.ValidationError("Stock cannot be negative.")
        
        return value
        
    def validate_slug(self, value):
        if self.instance is None:
            if Product.objects.filter(slug = value).exists():
                raise serializers.ValidationError("Slug must be unique.")
        else:
            if Product.objects.filter(slug=value).exclude(pk=self.instance.pk).exists():
                raise serializers.ValidationError("Slug must be unique.")

        if not re.match('^[a-z0-9]+(?:-[a-z0-9]+)*$', value):
            raise serializers.ValidationError("Slug must be lowercase and can only contain hyphens and alphanumeric characters.")
        
        return value
        
    def validate(self, data):
        return data