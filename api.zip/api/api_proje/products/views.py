from .models import Product
from rest_framework.decorators import api_view,permission_classes
from .serializers import ProductSerializer,ProductDetailsSerializers,ProductListSerializers
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAdminUser


@api_view(["GET"])
def catalog_list_products(request):
    #    """Catalog: List all products"""

    product=Product.objects.filter(stock__gt=0) # stock_gt=skot 0 oanı getime
    serializer=ProductSerializer(product,many=True)
    return Response(serializer.data)

@api_view(["GET"])
def catalog_list_products_by_catid(request,id):
    #catalog: list all product by catagol id
    product=Product.objects.filter(category=id)
    serializer=ProductListSerializers(product,many=True)
    return Response(serializer.data)

@api_view(["GET"])
def catalog_product_details(request,pk):
    #catalog :get product details by id
    try:
     product=Product.objects.get(pk=pk)
    except product.DoesNotExist:
       return Response({"Error":"Product not found"},status=404)
    serializer=ProductDetailsSerializers(product,many=True)
    return Response(serializer.data)

@api_view(['GET'])
@permission_classes([IsAdminUser])
def admin_list_products(request):
    """Admin: List all products"""
    products = Product.objects.all()
    serializer = ProductListSerializer(products, many=True)
    return Response(serializer.data)


@api_view(['GET'])
@permission_classes([IsAdminUser])
def admin_product_details(request,pk):
    """Admin: Get Product Details By Id"""
    try:
        product = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        return Response({'Error':'Product not found'}, status=404)
    
    serializer = ProductDetailsSerializer(product)
    return Response(serializer.data)
    

@api_view(['POST'])
@permission_classes([IsAdminUser])
def admin_create_product(request):
    """Admin: Create Product"""
    serializer = ProductSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
@permission_classes([IsAdminUser])
def admin_edit_product(request,pk):
    """Admin: Update Product"""
    product = Product.objects.get(pk=pk)
    serializer = ProductSerializer(product,data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

@api_view(['DELETE'])
@permission_classes([IsAdminUser])
def admin_delete_product(request,pk):
    """Admin: Delete Product"""
    try:
        product = Product.objects.get(pk=pk)
    except Product.DoesNotExist:
        return Response({'Error':'Product not found'}, status=404)
    product.delete()
    return Response({'message': 'Product deleted.'}, status=status.HTTP_204_NO_CONTENT)