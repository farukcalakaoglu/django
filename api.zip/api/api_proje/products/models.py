from django.db import models
from categories.models import kategori
# Create your models here.
class Product(models.Model):
    name=models.CharField(max_length=200)
    description=models.CharField(max_length=200)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    slug=models.SlugField()
    category=models.ForeignKey(kategori,on_delete=models.CASCADE,related_name="products")
    stock=models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return self.name